<!DOCTYPE html>
<html>
<head>

	<style type="text/css">
	.left p{
	font-size: 23px;
	}
	.right ul li{
	display: inline-block;
	list-style: none;
	margin-left: 30px;
	}
	</style>
</head>
<body>


<section style="line-height:50px; background: black; color: red;">
	
	<div class="container-fluid row text-center">
		<div class="left col-lg-4 col-md-4 col-sm-12">
			<p>Blood Bank Management System</p>
		</div>
		<div class="right col-lg-8 col-md-8 col-sm-12">
			<ul>
				<li>
					FOLLOW US ON :
				</li>
				<li>
					<a href="#">Instagram</a>
				</li>
				<li>
					<a href="#">Facebook</a>
				</li>
				<li>
					<a href="#">Twitter</a>
				</li>
			</ul>
		</div>
	</div>

</section>
</body>
</html>
