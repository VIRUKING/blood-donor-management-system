-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 01, 2020 at 09:50 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bbms`
--

-- --------------------------------------------------------

--
-- Table structure for table `donor`
--

CREATE TABLE `donor` (
  `id` int(255) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Fname` varchar(255) NOT NULL,
  `Mname` varchar(255) NOT NULL,
  `Lname` varchar(255) NOT NULL,
  `Gender` varchar(255) NOT NULL,
  `Bloodgroup` varchar(255) NOT NULL,
  `Bdate` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `City` varchar(255) NOT NULL,
  `Dondate` varchar(255) NOT NULL,
  `Stats` varchar(255) NOT NULL,
  `Temp` varchar(255) NOT NULL,
  `Pulse` varchar(255) NOT NULL,
  `Bp` varchar(255) NOT NULL,
  `Weight` int(255) NOT NULL,
  `Hemoglobin` varchar(255) NOT NULL,
  `Hbsag` varchar(255) NOT NULL,
  `Aids` varchar(255) NOT NULL,
  `MalariaSmear` varchar(255) NOT NULL,
  `Hematocrit` varchar(255) NOT NULL,
  `Mobile1` varchar(255) NOT NULL,
  `Mobile2` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donor`
--

INSERT INTO `donor` (`id`, `Username`, `Fname`, `Mname`, `Lname`, `Gender`, `Bloodgroup`, `Bdate`, `Address`, `City`, `Dondate`, `Stats`, `Temp`, `Pulse`, `Bp`, `Weight`, `Hemoglobin`, `Hbsag`, `Aids`, `MalariaSmear`, `Hematocrit`, `Mobile1`, `Mobile2`) VALUES
(1, '', 'Abhishek', 'Pankajbhai', 'Maru', 'male', 'B+', '2003-09-15', 'Near old police station, aadityana,porbandat,360575', 'Porbandar', '2020-09-28', 'Normal', '34', '79', '80|120', 55, '67', 'Nagative', 'Nagative', 'Nagative', '67', '1234567890', '987654321'),
(2, '', 'User2Fname', 'User2Mname', 'User2Lname', 'male', 'O+', '1111-11-11', 'Unknown User2', 'Porbandar', '1111-11-11', 'Normal', '56', '65', '11|120', 54, '89', 'Nagative', 'Nagative', 'Nagative', '89', '1234967689', '1234962289'),
(5, 'abhi', 'Abhishek', 'Pankajbhai', 'Maru', 'male', 'O+', '2220-12-18', 'You Know my address', 'Porbandar', '9992-12-11', 'Normal', '56', '66', '67|120', 71, '87', 'Nagative', 'Nagative', 'Nagative', '77', '2147483647', '990990099'),
(15, 'xyz', 'laksndl', 'kllklkdlk', 'basic', 'male', 'A-', '', 'I AM NOT TELL YOU\r\n', 'PORBANDAR', '', '', '', '', '', 0, '', 'Nagative', 'Nagative', 'Nagative', '', '', ''),
(23, 'abc', 'i ', 'am ', 'abc', 'male', 'A+', '1111-11-11', 'i am abc', 'PORBANDAR', '1999-12-19', 'NOrmal', '19', '91', '99', 11, '11', 'Nagative', 'Nagative', 'Nagative', '11', '8888888888', '8888888888');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(255) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `Username`, `Password`) VALUES
(3, 'Abhi_Maru', '$2y$10$p6WdVP6aiFCdF1rEJsUFI.X8Cy1wd76MvEI8Ccsj0Qgvr1inFshkm'),
(4, 'abhi', '$2y$10$KoIRvflneD4hUL3E1oYBb.InubfZJXQdSNqz5bB.bg5qDdCa8E2QS'),
(6, 'Darshan', '$2y$10$YGFHSUCtpi.ltNLkU5Y5quASmV7Uo9Shy1ZlssSH/.HXn6Rovz3F2'),
(7, 'xyz', '$2y$10$ivaAgeetO1DEpc094716t.vFmEBkwHGPYFVWblmPAsgFlKtkiETGK'),
(8, '964', '$2y$10$v3rbtsu5qvCnWnYhMrr/kubQzaLvuIYHOkxy1O2le9xvbB6b6eyb6'),
(9, 'Yash', '$2y$10$EzV5qy4oDRB6C8YcF80DFe/3frU7YT0Lwpe0PphdXFH0UYSNSkLv2'),
(10, 'Random', '$2y$10$GIXgHcvEKNZxSX000Oa9o.4VkD.eV7A0EnvGGdPQcvLYzist4mnf6'),
(11, 'newuser', '$2y$10$E.D8nD5UOQ88gFaIrD71Iu1v48Am5wXOORITUCO6iFDRwPq4xeUB2'),
(13, 'abc', '$2y$10$s3Y8QCFfAkMZz/FZuygt.OLxmMyPjhALkFuiMRrNvWGDju7pE1ny2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donor`
--
ALTER TABLE `donor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `donor`
--
ALTER TABLE `donor`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
